
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyDo2SV_irfNbS_ca_ggwEGyEZklCEpJ9so",
  authDomain: "facebook-53a1f.firebaseapp.com",
  projectId: "facebook-53a1f",
  storageBucket: "facebook-53a1f.firebasestorage.app",
  messagingSenderId: "457363223975",
  appId: "1:457363223975:web:eb9f7af23376c344a93282",
  measurementId: "G-M11C47603V"
};


export const app = initializeApp(firebaseConfig);